package examen;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

// SOLUCIÓN del ejercicio 2 (simulacro 2)
public class Ejercicio2Ficheros {

    static final int TAM_NOMBRE = 15;                          // caracteres (2 bytes cada uno)
    static final int TAM_REGISTRO = TAM_NOMBRE * 2 + 4 + 4;    // nombre + puntos + jugados = 38 bytes

    // Una fila de la clasificación
    static class Equipo {
        String nombre;
        int jugados, ganados, empatados, perdidos, aFavor, enContra;
        Equipo(String nombre) { this.nombre = nombre; }
        int puntos() { return ganados * 3 + empatados; }
        int diferencia() { return aFavor - enContra; }
    }

    // Lo que devuelve la lectura del XML
    static String temporada;
    static int incorrectos;

    public static void main(String[] args) {
        String fXml = "combates.xml";
        clasificacion(fXml);
        System.out.println();
        exportarTxt(fXml, "clasificacion.txt");
        System.out.println();
        guardarFichas(fXml, "fichas.dat");
        consultarFicha("fichas.dat", 2);
        sumarPuntos("fichas.dat", 2, 3);
        consultarFicha("fichas.dat", 2);
        consultarFicha("fichas.dat", 9);
        sumarPuntos("fichas.dat", 0, 3);
        System.out.println();
        clasificacion("noexiste.xml");
    }

    // ---------- lectura común: XML -> equipos ordenados ----------
    static List<Equipo> leerClasificacion(String fXml) {
        Map<String, Equipo> equipos = new LinkedHashMap<>();
        incorrectos = 0;
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(fXml));
            temporada = doc.getDocumentElement().getAttribute("temporada");      // atributo de la raíz
            NodeList combates = doc.getElementsByTagName("combate");
            for (int i = 0; i < combates.getLength(); i++) {
                Element c = (Element) combates.item(i);
                String local = texto(c, "local");
                String visitante = texto(c, "visitante");
                String resultado = texto(c, "resultado");
                try {
                    if (local.isEmpty() || visitante.isEmpty() || local.equals(visitante)) throw new NumberFormatException();
                    String[] r = resultado.split("-");
                    if (r.length != 2) throw new NumberFormatException();
                    int gl = Integer.parseInt(r[0].trim());
                    int gv = Integer.parseInt(r[1].trim());
                    Equipo l = equipos.computeIfAbsent(local, Equipo::new);
                    Equipo v = equipos.computeIfAbsent(visitante, Equipo::new);
                    apuntar(l, gl, gv);
                    apuntar(v, gv, gl);
                } catch (NumberFormatException e) {
                    incorrectos++;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("No existe el fichero " + fXml);
            return null;
        } catch (Exception e) {
            System.out.println("Error al leer " + fXml + ": " + e.getMessage());
            return null;
        }
        List<Equipo> lista = new ArrayList<>(equipos.values());
        lista.sort((a, b) -> {
            if (a.puntos() != b.puntos()) return b.puntos() - a.puntos();
            if (a.diferencia() != b.diferencia()) return b.diferencia() - a.diferencia();
            return a.nombre.compareTo(b.nombre);
        });
        return lista;
    }

    static void apuntar(Equipo e, int propios, int rivales) {
        e.jugados++;
        e.aFavor += propios;
        e.enContra += rivales;
        if (propios > rivales) e.ganados++;
        else if (propios == rivales) e.empatados++;
        else e.perdidos++;
    }

    static String texto(Element padre, String etiqueta) {
        NodeList l = padre.getElementsByTagName(etiqueta);
        return l.getLength() == 0 ? "" : l.item(0).getTextContent().trim();
    }

    // ---------- a) ----------
    public static void clasificacion(String fXml) {
        List<Equipo> lista = leerClasificacion(fXml);
        if (lista == null) return;
        System.out.println("CLASIFICACIÓN LIGA " + temporada);
        System.out.println("Pos Entrenador  PJ  G  E  P  Dif  Pts");
        int pos = 1;
        for (Equipo e : lista) {
            System.out.printf("%3d %-10s %3d %2d %2d %2d %+4d %4d%n", pos++, e.nombre, e.jugados,
                    e.ganados, e.empatados, e.perdidos, e.diferencia(), e.puntos());
        }
        System.out.println("Combates incorrectos: " + incorrectos);
    }

    // ---------- b) ----------
    public static void exportarTxt(String fXml, String fTxt) {
        List<Equipo> lista = leerClasificacion(fXml);
        if (lista == null) return;
        try (PrintWriter pw = new PrintWriter(new FileWriter(fTxt, StandardCharsets.UTF_8))) {
            pw.println("pos;entrenador;puntos;ganados;empatados;perdidos;diferencia");
            int pos = 1;
            for (Equipo e : lista) {
                pw.println(pos++ + ";" + e.nombre + ";" + e.puntos() + ";" + e.ganados + ";" + e.empatados + ";"
                        + e.perdidos + ";" + e.diferencia());
            }
            System.out.println("Clasificación exportada a " + fTxt + " (" + lista.size() + " entrenadores)");
        } catch (IOException e) {
            System.out.println("Error al escribir " + fTxt + ": " + e.getMessage());
        }
    }

    // ---------- c) ----------
    public static void guardarFichas(String fXml, String fDat) {
        List<Equipo> lista = leerClasificacion(fXml);
        if (lista == null) return;
        try (RandomAccessFile raf = new RandomAccessFile(fDat, "rw")) {
            raf.setLength(0);                                     // "rw" no vacía el fichero
            for (Equipo e : lista) {
                escribirNombre(raf, e.nombre);
                raf.writeInt(e.puntos());
                raf.writeInt(e.jugados);
            }
            System.out.println("Fichas guardadas en " + fDat + ": " + lista.size() + " registros, " + raf.length() + " bytes");
        } catch (IOException e) {
            System.out.println("Error al escribir " + fDat + ": " + e.getMessage());
        }
    }

    static void escribirNombre(RandomAccessFile raf, String nombre) throws IOException {
        for (int i = 0; i < TAM_NOMBRE; i++) raf.writeChar(i < nombre.length() ? nombre.charAt(i) : ' ');
    }

    static String leerNombre(RandomAccessFile raf) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < TAM_NOMBRE; i++) sb.append(raf.readChar());
        return sb.toString().trim();
    }

    // true si la posición existe; si no, avisa
    static boolean posicionValida(RandomAccessFile raf, int pos) throws IOException {
        long total = raf.length() / TAM_REGISTRO;
        if (pos < 1 || pos > total) {
            System.out.println("No existe la posición " + pos + ". Hay " + total + " fichas");
            return false;
        }
        return true;
    }

    public static void consultarFicha(String fDat, int pos) {
        try (RandomAccessFile raf = new RandomAccessFile(fDat, "r")) {
            if (!posicionValida(raf, pos)) return;
            raf.seek((long) (pos - 1) * TAM_REGISTRO);
            String nombre = leerNombre(raf);
            int puntos = raf.readInt();
            int jugados = raf.readInt();
            System.out.println("Posición " + pos + ": " + nombre + ", " + puntos + " puntos en " + jugados + " combates");
        } catch (FileNotFoundException e) {
            System.out.println("No existe el fichero " + fDat);
        } catch (IOException e) {
            System.out.println("Error al leer " + fDat + ": " + e.getMessage());
        }
    }

    public static void sumarPuntos(String fDat, int pos, int extra) {
        try (RandomAccessFile raf = new RandomAccessFile(fDat, "rw")) {
            if (!posicionValida(raf, pos)) return;
            long inicio = (long) (pos - 1) * TAM_REGISTRO;
            raf.seek(inicio);
            String nombre = leerNombre(raf);
            long posPuntos = inicio + TAM_NOMBRE * 2;           // los puntos van justo después del nombre
            raf.seek(posPuntos);
            int antes = raf.readInt();
            raf.seek(posPuntos);                                // volver: readInt ha avanzado 4 bytes
            raf.writeInt(antes + extra);
            System.out.println(nombre + ": " + antes + " -> " + (antes + extra) + " puntos");
        } catch (IOException e) {
            System.out.println("Error con " + fDat + ": " + e.getMessage());
        }
    }
}
