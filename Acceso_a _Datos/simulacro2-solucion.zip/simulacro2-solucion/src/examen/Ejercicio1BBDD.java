package examen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// SOLUCIÓN del ejercicio 1 (simulacro 2)
public class Ejercicio1BBDD {

    static final String URL = "jdbc:mysql://localhost:3306/pokemondb";
    static final String USUARIO = "alumno";
    static final String PASSWORD = "abc123";

    static final String[] ESTADISTICAS = {"ps", "ataque", "defensa", "especial", "velocidad"};
    static final String[] ETIQUETAS = {"PS", "Ataque", "Defensa", "Especial", "Velocidad"};

    public static void main(String[] args) {
        compararPokemon("Pikachu", "Charmander");
        compararPokemon("Snorlax", "Mewtwo");
        compararPokemon("Doduo", "Pidgey");
        compararPokemon("Pikachu", "Agumon");
        System.out.println();
        evolucionesConPiedra("Piedra fuego");
        evolucionesConPiedra("Piedra trueno");
        evolucionesConPiedra("Piedra arcoíris");
        System.out.println();
        borrarPokemon("Pikachu");
        borrarPokemon("Pikachu");
        borrarPokemon("Ivysaur");
        evolucionesConPiedra("Piedra trueno");
    }

    static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }

    static int idPokemon(Connection con, String nombre) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT numero_pokedex FROM pokemon WHERE nombre = ?")) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }

    // Las 5 estadísticas, o null si el pokemon no tiene fila en estadisticas_base
    static int[] estadisticas(Connection con, int numero) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT ps, ataque, defensa, especial, velocidad FROM estadisticas_base WHERE numero_pokedex = ?")) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                int[] s = new int[5];
                for (int i = 0; i < 5; i++) s[i] = rs.getInt(i + 1);
                return s;
            }
        }
    }

    // ---------- a) ----------
    public static void compararPokemon(String a, String b) {
        if (a.equalsIgnoreCase(b)) {
            System.out.println("Tienes que indicar dos pokemon distintos");
            return;
        }
        try (Connection con = conectar()) {
            int na = idPokemon(con, a), nb = idPokemon(con, b);
            if (na == -1 || nb == -1) {
                System.out.println("El pokemon " + (na == -1 ? a : b) + " no está en la pokedex");
                return;
            }
            int[] sa = estadisticas(con, na), sb = estadisticas(con, nb);
            if (sa == null || sb == null) {
                System.out.println("No hay estadísticas registradas de " + (sa == null ? a : b));
                return;
            }
            System.out.printf("%-10s %10s %10s  %s%n", "", a, b, "Mejor");
            int ta = 0, tb = 0, ganaA = 0, ganaB = 0;
            for (int i = 0; i < 5; i++) {
                String mejor = sa[i] > sb[i] ? a : sb[i] > sa[i] ? b : "Empate";
                if (sa[i] > sb[i]) ganaA++;
                if (sb[i] > sa[i]) ganaB++;
                ta += sa[i];
                tb += sb[i];
                System.out.printf("%-10s %10d %10d  %s%n", ETIQUETAS[i], sa[i], sb[i], mejor);
            }
            System.out.printf("%-10s %10d %10d  %s%n", "Total", ta, tb, ta > tb ? a : tb > ta ? b : "Empate");
            System.out.println(a + " gana en " + veces(ganaA) + " y " + b + " en " + veces(ganaB));
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    static String veces(int n) {
        return n + (n == 1 ? " estadística" : " estadísticas");
    }

    // ---------- b) ----------
    public static void evolucionesConPiedra(String piedra) {
        try (Connection con = conectar()) {
            int idPiedra;
            try (PreparedStatement ps = con.prepareStatement("SELECT id_tipo_piedra FROM tipo_piedra WHERE nombre_piedra = ?")) {
                ps.setString(1, piedra);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        System.out.println(piedra + " no es una piedra de evolución");
                        return;
                    }
                    idPiedra = rs.getInt(1);
                }
            }
            // origen (tiene la forma con esa piedra) -> sus evoluciones. LEFT JOIN por si no tuviera evolución
            String sql = "SELECT o.nombre AS origen, d.nombre AS destino "
                       + "FROM pokemon_forma_evolucion pfe "
                       + "JOIN piedra pi ON pi.id_forma_evolucion = pfe.id_forma_evolucion "
                       + "JOIN pokemon o ON o.numero_pokedex = pfe.numero_pokedex "
                       + "LEFT JOIN evoluciona_de e ON e.pokemon_origen = o.numero_pokedex "
                       + "LEFT JOIN pokemon d ON d.numero_pokedex = e.pokemon_evolucionado "
                       + "WHERE pi.id_tipo_piedra = ? ORDER BY o.numero_pokedex, d.numero_pokedex";
            Map<String, List<String>> evos = new LinkedHashMap<>();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idPiedra);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        List<String> l = evos.computeIfAbsent(rs.getString("origen"), k -> new ArrayList<>());
                        if (rs.getString("destino") != null) l.add(rs.getString("destino"));
                    }
                }
            }
            if (evos.isEmpty()) {
                System.out.println("Ningún pokemon evoluciona con " + piedra);
                return;
            }
            System.out.println("Pokemon que evolucionan con " + piedra + ": " + evos.size());
            for (Map.Entry<String, List<String>> e : evos.entrySet())
                System.out.println(" - " + e.getKey() + " -> " + (e.getValue().isEmpty() ? "?" : String.join(", ", e.getValue())));
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    // ---------- c) ----------
    // Orden: primero las tablas hijas (las que apuntan a pokemon), al final pokemon. Si no, error 1451.
    static final String[][] BORRADOS = {
        {"pokemon_tipo", "DELETE FROM pokemon_tipo WHERE numero_pokedex = ?"},
        {"estadisticas_base", "DELETE FROM estadisticas_base WHERE numero_pokedex = ?"},
        {"pokemon_movimiento_forma", "DELETE FROM pokemon_movimiento_forma WHERE numero_pokedex = ?"},
        {"pokemon_forma_evolucion", "DELETE FROM pokemon_forma_evolucion WHERE numero_pokedex = ?"},
        {"evoluciona_de", "DELETE FROM evoluciona_de WHERE pokemon_origen = ? OR pokemon_evolucionado = ?"},
        {"pokemon", "DELETE FROM pokemon WHERE numero_pokedex = ?"},
    };

    public static void borrarPokemon(String nombre) {
        try (Connection con = conectar()) {
            int numero = idPokemon(con, nombre);
            if (numero == -1) {
                System.out.println("El pokemon " + nombre + " no está en la pokedex");
                return;
            }
            con.setAutoCommit(false);
            try {
                List<String> lineas = new ArrayList<>();
                int total = 0;
                for (String[] b : BORRADOS) {
                    try (PreparedStatement ps = con.prepareStatement(b[1])) {
                        ps.setInt(1, numero);
                        if (b[1].contains("OR")) ps.setInt(2, numero);    // evoluciona_de: dos ?
                        int n = ps.executeUpdate();
                        total += n;
                        lineas.add(" - " + b[0] + ": " + n);
                    }
                }
                con.commit();
                System.out.println("Borrado " + nombre + " (#" + numero + "):");
                for (String l : lineas) System.out.println(l);
                System.out.println("Total: " + total + " filas");
            } catch (SQLException e) {
                con.rollback();
                System.out.println("No se ha borrado nada: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }
}
