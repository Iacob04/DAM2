package plantillas;

import java.util.List;

// Prueba de la variante DataOutputStream: TXT -> .dat (Data) -> lista
public class PruebaData {
    public static void main(String[] args) {
        List<Pokemon> lista = Conversor.leerTxt("pokemons.txt");
        Conversor.escribirBinarioData(lista, "pokemons_data.dat");
        for (Pokemon p : Conversor.leerBinarioData("pokemons_data.dat")) System.out.println(p);
    }
}
