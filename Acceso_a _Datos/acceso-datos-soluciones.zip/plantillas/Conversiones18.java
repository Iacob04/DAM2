package plantillas;

import java.util.List;

// Las 18 conversiones. Cada una = un leer + un escribir de Conversor.java.
// Para usarlas en el examen copia el método y los dos de Conversor que llama.
public class Conversiones18 {

    // ===== [C01] =====
    // TXT -> XML
    public static void txtAXml(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerTxt(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirXml(lista, destino);
    }
    // ===== FIN =====

    // ===== [C02] =====
    // TXT -> JSON
    public static void txtAJson(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerTxt(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirJson(lista, destino);
    }
    // ===== FIN =====

    // ===== [C03] =====
    // TXT -> BD
    public static void txtABD(String origen) {
        List<Pokemon> lista = Conversor.leerTxt(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBD(lista);
    }
    // ===== FIN =====

    // ===== [C04] =====
    // Binario -> XML
    public static void binarioAXml(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerBinario(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirXml(lista, destino);
    }
    // ===== FIN =====

    // ===== [C05] =====
    // Binario -> JSON
    public static void binarioAJson(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerBinario(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirJson(lista, destino);
    }
    // ===== FIN =====

    // ===== [C06] =====
    // Binario -> BD
    public static void binarioABD(String origen) {
        List<Pokemon> lista = Conversor.leerBinario(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBD(lista);
    }
    // ===== FIN =====

    // ===== [C07] =====
    // XML -> JSON
    public static void xmlAJson(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerXml(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirJson(lista, destino);
    }
    // ===== FIN =====

    // ===== [C08] =====
    // XML -> TXT
    public static void xmlATxt(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerXml(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirTxt(lista, destino);
    }
    // ===== FIN =====

    // ===== [C09] =====
    // XML -> Binario
    public static void xmlABinario(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerXml(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBinario(lista, destino);
    }
    // ===== FIN =====

    // ===== [C10] =====
    // XML -> BD
    public static void xmlABD(String origen) {
        List<Pokemon> lista = Conversor.leerXml(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBD(lista);
    }
    // ===== FIN =====

    // ===== [C11] =====
    // JSON -> XML
    public static void jsonAXml(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerJson(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirXml(lista, destino);
    }
    // ===== FIN =====

    // ===== [C12] =====
    // JSON -> TXT
    public static void jsonATxt(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerJson(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirTxt(lista, destino);
    }
    // ===== FIN =====

    // ===== [C13] =====
    // JSON -> Binario
    public static void jsonABinario(String origen, String destino) {
        List<Pokemon> lista = Conversor.leerJson(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBinario(lista, destino);
    }
    // ===== FIN =====

    // ===== [C14] =====
    // JSON -> BD
    public static void jsonABD(String origen) {
        List<Pokemon> lista = Conversor.leerJson(origen);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBD(lista);
    }
    // ===== FIN =====

    // ===== [C15] =====
    // BD -> XML
    public static void bdAXml(List<Integer> numeros, String destino) {
        List<Pokemon> lista = Conversor.leerBD(numeros);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirXml(lista, destino);
    }
    // ===== FIN =====

    // ===== [C16] =====
    // BD -> JSON
    public static void bdAJson(List<Integer> numeros, String destino) {
        List<Pokemon> lista = Conversor.leerBD(numeros);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirJson(lista, destino);
    }
    // ===== FIN =====

    // ===== [C17] =====
    // BD -> TXT
    public static void bdATxt(List<Integer> numeros, String destino) {
        List<Pokemon> lista = Conversor.leerBD(numeros);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirTxt(lista, destino);
    }
    // ===== FIN =====

    // ===== [C18] =====
    // BD -> Binario
    public static void bdABinario(List<Integer> numeros, String destino) {
        List<Pokemon> lista = Conversor.leerBD(numeros);
        if (lista == null) return;                 // no se pudo leer: no se escribe nada
        Conversor.escribirBinario(lista, destino);
    }
    // ===== FIN =====

    // Prueba: java Conversiones18 prep  (crea los ficheros de origen)  y luego  java Conversiones18 01 ... 18
    public static void main(String[] args) {
        List<Integer> numeros = List.of(1, 25, 133);       // los pokemon que se sacan de la BD
        switch (args[0]) {
            case "prep" -> {
                List<Pokemon> base = Conversor.leerTxt("pokemons.txt");
                Conversor.escribirBinario(base, "pokemons.dat");
                Conversor.escribirXml(base, "pokemons.xml");
                Conversor.escribirJson(base, "pokemons.json");
            }
            case "ver" -> {                                // comprobar un .dat leyéndolo
                List<Pokemon> l = Conversor.leerBinario(args[1]);
                if (l != null) for (Pokemon p : l) System.out.println(p);
            }
            case "01" -> txtAXml("pokemons.txt", "salida01.xml");
            case "02" -> txtAJson("pokemons.txt", "salida02.json");
            case "03" -> txtABD("pokemons.txt");
            case "04" -> binarioAXml("pokemons.dat", "salida04.xml");
            case "05" -> binarioAJson("pokemons.dat", "salida05.json");
            case "06" -> binarioABD("pokemons.dat");
            case "07" -> xmlAJson("pokemons.xml", "salida07.json");
            case "08" -> xmlATxt("pokemons.xml", "salida08.txt");
            case "09" -> xmlABinario("pokemons.xml", "salida09.dat");
            case "10" -> xmlABD("pokemons.xml");
            case "11" -> jsonAXml("pokemons.json", "salida11.xml");
            case "12" -> jsonATxt("pokemons.json", "salida12.txt");
            case "13" -> jsonABinario("pokemons.json", "salida13.dat");
            case "14" -> jsonABD("pokemons.json");
            case "15" -> bdAXml(numeros, "salida15_desde_bd.xml");
            case "16" -> bdAJson(numeros, "salida16_desde_bd.json");
            case "17" -> bdATxt(numeros, "salida17_desde_bd.txt");
            case "18" -> bdABinario(numeros, "salida18_desde_bd.dat");
        }
    }
}
