package plantillas;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

// Convertir de X a Y = leerX(...) + escribirY(...).
// Todos los leer devuelven null si no se ha podido leer: así nunca se machaca un fichero con una lista vacía.
public class Conversor {

    static final String URL = "jdbc:mysql://localhost:3306/pokemondb";
    static final String USUARIO = "alumno";
    static final String PASSWORD = "abc123";

    // ===== [MAIN] =====
    public static void main(String[] args) {
        List<Pokemon> lista = leerTxt("pokemons.txt");     // TXT -> objetos
        if (lista == null) return;

        escribirXml(lista, "pokemons.xml");                // objetos -> XML
        escribirJson(lista, "pokemons.json");              // objetos -> JSON

        List<Pokemon> desdeXml = leerXml("pokemons.xml");  // XML -> objetos
        if (desdeXml != null) escribirTxt(desdeXml, "desde_xml.txt");      // XML -> TXT

        List<Pokemon> desdeJson = leerJson("pokemons.json");
        if (desdeJson != null) escribirXml(desdeJson, "desde_json.xml");   // JSON -> XML

        List<Pokemon> desdeBD = leerBD(List.of(1, 4, 133));                // BD -> objetos
        if (desdeBD != null) escribirJson(desdeBD, "desde_bd.json");       // BD -> JSON

        escribirBD(lista);                                 // objetos -> BD
    }
    // ===== FIN =====

    // ===== [TXT-LEER] =====
    // Formato: 152, Chikorita, 6.4, 0.9, Planta[, Tipo2]
    public static List<Pokemon> leerTxt(String fichero) {
        List<Pokemon> lista = new ArrayList<>();
        try {
            List<String> lineas = Files.readAllLines(Path.of(fichero), StandardCharsets.UTF_8);
            for (int i = 0; i < lineas.size(); i++) {           // i = 1 si hay cabecera
                String linea = lineas.get(i);
                if (linea.isBlank()) continue;
                String[] c = linea.split(",");
                for (int j = 0; j < c.length; j++) c[j] = c[j].trim();
                if (c.length < 5) {                              // línea mal formada: se salta
                    System.out.println("Línea " + (i + 1) + " incorrecta: " + linea);
                    continue;
                }
                try {
                    List<String> tipos = Arrays.asList(c).subList(4, c.length);   // del 5º campo al final
                    lista.add(new Pokemon(Integer.parseInt(c[0]), c[1],
                            Double.parseDouble(c[2]), Double.parseDouble(c[3]), tipos));
                } catch (NumberFormatException e) {
                    System.out.println("Línea " + (i + 1) + " con un número incorrecto: " + linea);
                }
            }
            return lista;
        } catch (IOException e) {
            System.out.println("Error al leer " + fichero + ": " + e.getMessage());
            return null;
        }
    }
    // ===== FIN =====

    // ===== [TXT-ESCRIBIR] =====
    public static void escribirTxt(List<Pokemon> lista, String fichero) {
        List<String> lineas = new ArrayList<>();
        for (Pokemon p : lista) {
            lineas.add(p.getNumero() + ", " + p.getNombre() + ", " + p.getPeso() + ", "
                    + p.getAltura() + ", " + String.join(", ", p.getTipos()));
        }
        try {
            Files.write(Path.of(fichero), lineas, StandardCharsets.UTF_8);    // sobrescribe
            System.out.println("Escritos " + lista.size() + " registros en " + fichero);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }
    // ===== FIN =====

    // ===== [BIN-LEER] =====
    // Binario de OBJETOS: la lista entera es un único objeto (como guardarListaPokemons del profe).
    // Pokemon tiene que implementar Serializable.
    @SuppressWarnings("unchecked")
    public static List<Pokemon> leerBinario(String fichero) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fichero))) {
            return (List<Pokemon>) ois.readObject();          // el cast es obligatorio
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al leer " + fichero + ": " + e.getMessage());
            return null;
        }
    }
    // ===== FIN =====

    // ===== [BIN-ESCRIBIR] =====
    public static void escribirBinario(List<Pokemon> lista, String fichero) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero))) {
            oos.writeObject(new ArrayList<>(lista));         // ArrayList es Serializable (una List cualquiera puede no serlo)
            System.out.println("Escritos " + lista.size() + " registros en " + fichero);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }
    // ===== FIN =====

    // ===== [BINDATA] =====
    // Variante con DataOutputStream (tipos primitivos, como escribirFichero del profe).
    // Se escriben los campos uno a uno; los tipos van precedidos de cuántos hay.
    // Se lee en el MISMO orden y con los MISMOS tipos, hasta EOFException.
    public static void escribirBinarioData(List<Pokemon> lista, String fichero) {
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(fichero))) {
            for (Pokemon p : lista) {
                dos.writeInt(p.getNumero());
                dos.writeUTF(p.getNombre());
                dos.writeDouble(p.getPeso());
                dos.writeDouble(p.getAltura());
                dos.writeInt(p.getTipos().size());             // cuántos tipos vienen detrás
                for (String t : p.getTipos()) dos.writeUTF(t);
            }
            System.out.println("Escritos " + lista.size() + " registros en " + fichero);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }

    public static List<Pokemon> leerBinarioData(String fichero) {
        List<Pokemon> lista = new ArrayList<>();
        try (DataInputStream dis = new DataInputStream(new FileInputStream(fichero))) {
            while (true) {
                int numero = dis.readInt();
                String nombre = dis.readUTF();
                double peso = dis.readDouble();
                double altura = dis.readDouble();
                int n = dis.readInt();
                List<String> tipos = new ArrayList<>();
                for (int i = 0; i < n; i++) tipos.add(dis.readUTF());
                lista.add(new Pokemon(numero, nombre, peso, altura, tipos));
            }
        } catch (EOFException e) {
            return lista;                                      // fin del fichero: lo normal
        } catch (IOException e) {
            System.out.println("Error al leer " + fichero + ": " + e.getMessage());
            return null;
        }
    }
    // ===== FIN =====

    // ===== [XML-LEER] =====
    // <pokedex><pokemon numero="1"><nombre>..</nombre><peso>..</peso><altura>..</altura>
    //          <tipo>..</tipo><tipo>..</tipo></pokemon></pokedex>
    public static List<Pokemon> leerXml(String fichero) {
        List<Pokemon> lista = new ArrayList<>();
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(fichero));
            NodeList nodos = doc.getElementsByTagName("pokemon");
            for (int i = 0; i < nodos.getLength(); i++) {
                Element e = (Element) nodos.item(i);
                int numero = Integer.parseInt(e.getAttribute("numero"));     // ATRIBUTO
                String nombre = texto(e, "nombre");                         // ETIQUETA
                double peso = Double.parseDouble(texto(e, "peso"));
                double altura = Double.parseDouble(texto(e, "altura"));
                List<String> tipos = new ArrayList<>();                     // etiqueta REPETIDA
                NodeList ts = e.getElementsByTagName("tipo");
                for (int j = 0; j < ts.getLength(); j++) tipos.add(ts.item(j).getTextContent().trim());
                lista.add(new Pokemon(numero, nombre, peso, altura, tipos));
            }
            return lista;
        } catch (Exception e) {
            System.out.println("Error al leer " + fichero + ": " + e.getMessage());
            return null;
        }
    }

    // Texto de la primera etiqueta hija con ese nombre ("" si no está)
    static String texto(Element padre, String etiqueta) {
        NodeList l = padre.getElementsByTagName(etiqueta);
        return l.getLength() == 0 ? "" : l.item(0).getTextContent().trim();
    }
    // ===== FIN =====

    // ===== [XML-ESCRIBIR] =====
    public static void escribirXml(List<Pokemon> lista, String fichero) {
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element raiz = doc.createElement("pokedex");
            doc.appendChild(raiz);
            for (Pokemon p : lista) {
                Element e = doc.createElement("pokemon");
                e.setAttribute("numero", String.valueOf(p.getNumero()));    // ATRIBUTO
                hijo(doc, e, "nombre", p.getNombre());                      // ETIQUETAS
                hijo(doc, e, "peso", String.valueOf(p.getPeso()));
                hijo(doc, e, "altura", String.valueOf(p.getAltura()));
                for (String t : p.getTipos()) hijo(doc, e, "tipo", t);     // una etiqueta por tipo
                raiz.appendChild(e);
            }
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            t.transform(new DOMSource(doc), new StreamResult(new File(fichero)));
            System.out.println("Escritos " + lista.size() + " registros en " + fichero);
        } catch (Exception e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }

    static void hijo(Document doc, Element padre, String etiqueta, String texto) {
        Element e = doc.createElement(etiqueta);
        e.setTextContent(texto);
        padre.appendChild(e);
    }
    // ===== FIN =====

    // ===== [JSON-LEER] =====
    // { "pokedex": [ { "numero": 1, "nombre": "...", "peso": 6.9, "altura": 0.7, "tipos": ["Planta"] } ] }
    public static List<Pokemon> leerJson(String fichero) {
        try (Reader r = new FileReader(fichero, StandardCharsets.UTF_8)) {
            Pokedex pokedex = new Gson().fromJson(r, Pokedex.class);
            if (pokedex == null || pokedex.getPokemons() == null) return new ArrayList<>();
            return pokedex.getPokemons();
        } catch (Exception e) {
            System.out.println("Error al leer " + fichero + ": " + e.getMessage());
            return null;
        }
    }
    // ===== FIN =====

    // ===== [JSON-ESCRIBIR] =====
    public static void escribirJson(List<Pokemon> lista, String fichero) {
        try (Writer w = new FileWriter(fichero, StandardCharsets.UTF_8)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(new Pokedex(lista), w);
            System.out.println("Escritos " + lista.size() + " registros en " + fichero);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }
    // ===== FIN =====

    // ===== [JSON-ARRAY] =====
    // Si el JSON empieza por [ (sin objeto raíz) no hace falta la clase Pokedex
    public static List<Pokemon> leerJsonArray(String fichero) {
        try (Reader r = new FileReader(fichero, StandardCharsets.UTF_8)) {
            Type tipo = new TypeToken<List<Pokemon>>() {}.getType();   // "List<Pokemon>" para Gson
            List<Pokemon> lista = new Gson().fromJson(r, tipo);
            return lista == null ? new ArrayList<>() : lista;
        } catch (Exception e) {
            System.out.println("Error al leer " + fichero + ": " + e.getMessage());
            return null;
        }
    }

    public static void escribirJsonArray(List<Pokemon> lista, String fichero) {
        try (Writer w = new FileWriter(fichero, StandardCharsets.UTF_8)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(lista, w);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }
    // ===== FIN =====

    // ===== [BD-LEER] =====
    // Un JOIN devuelve una fila por tipo: Bulbasaur sale dos veces (Planta y Veneno).
    // Se agrupan en Java con un LinkedHashMap numero -> Pokemon.
    public static List<Pokemon> leerBD(List<Integer> numeros) {
        String sql = "SELECT p.numero_pokedex, p.nombre, p.peso, p.altura, t.nombre AS tipo "
                   + "FROM pokemon p "
                   + "JOIN pokemon_tipo pt ON p.numero_pokedex = pt.numero_pokedex "
                   + "JOIN tipo t ON pt.id_tipo = t.id_tipo "
                   + "WHERE p.numero_pokedex = ? ORDER BY t.id_tipo";
        Map<Integer, Pokemon> mapa = new LinkedHashMap<>();
        try (Connection con = DriverManager.getConnection(URL, USUARIO, PASSWORD);
             PreparedStatement ps = con.prepareStatement(sql)) {
            for (int numero : numeros) {
                ps.setInt(1, numero);                       // mismo PreparedStatement, otro valor
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Pokemon p = mapa.get(numero);
                        if (p == null) {                    // primera fila de este pokemon
                            p = new Pokemon(numero, rs.getString("nombre"), rs.getDouble("peso"),
                                    rs.getDouble("altura"), new ArrayList<>());
                            mapa.put(numero, p);
                        }
                        p.getTipos().add(rs.getString("tipo"));
                    }
                }
            }
            return new ArrayList<>(mapa.values());
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
            return null;
        }
    }
    // ===== FIN =====

    // ===== [BD-ESCRIBIR] =====
    // Cada pokemon son 1 INSERT en pokemon + 1 por tipo en pokemon_tipo: transacción por pokemon.
    public static void escribirBD(List<Pokemon> lista) {
        try (Connection con = DriverManager.getConnection(URL, USUARIO, PASSWORD)) {
            con.setAutoCommit(false);
            int altas = 0;
            for (Pokemon p : lista) {
                if (existe(con, p.getNumero())) {
                    System.out.println("Ya existe el número " + p.getNumero() + ": " + p.getNombre() + " no se inserta");
                    continue;
                }
                try (PreparedStatement ins = con.prepareStatement("INSERT INTO pokemon VALUES (?, ?, ?, ?)");
                     PreparedStatement insTipo = con.prepareStatement("INSERT INTO pokemon_tipo VALUES (?, ?)")) {
                    ins.setInt(1, p.getNumero());
                    ins.setString(2, p.getNombre());
                    ins.setDouble(3, p.getPeso());
                    ins.setDouble(4, p.getAltura());
                    ins.executeUpdate();
                    for (String tipo : p.getTipos()) {
                        int idTipo = idTipo(con, tipo);
                        if (idTipo == -1) throw new SQLException("el tipo " + tipo + " no existe");
                        insTipo.setInt(1, p.getNumero());
                        insTipo.setInt(2, idTipo);
                        insTipo.executeUpdate();
                    }
                    con.commit();                              // el pokemon y sus tipos, todo junto
                    altas++;
                } catch (SQLException e) {
                    con.rollback();                            // ni pokemon ni tipos
                    System.out.println(p.getNombre() + " no se inserta: " + e.getMessage());
                }
            }
            System.out.println("Insertados " + altas + " de " + lista.size());
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    static boolean existe(Connection con, int numero) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT 1 FROM pokemon WHERE numero_pokedex = ?")) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    static int idTipo(Connection con, String nombre) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT id_tipo FROM tipo WHERE nombre = ?")) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }
    // ===== FIN =====
}
