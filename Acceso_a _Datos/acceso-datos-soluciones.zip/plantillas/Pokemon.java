package plantillas;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

// CLASE MODELO: un objeto por registro. Es lo único que cambia en cada examen.
// Para JSON, los nombres de los atributos SON las claves del JSON.
// Serializable: para el fichero binario de objetos (ObjectOutputStream).
public class Pokemon implements Serializable {

    private static final long serialVersionUID = 1L;   // sin esto, cambiar la clase rompe los .dat ya grabados

    private int numero;
    private String nombre;
    private double peso;
    private double altura;
    private List<String> tipos = new ArrayList<>();   // campo con varios valores

    public Pokemon() {                                 // Gson lo necesita
    }

    public Pokemon(int numero, String nombre, double peso, double altura, List<String> tipos) {
        this.numero = numero;
        this.nombre = nombre;
        this.peso = peso;
        this.altura = altura;
        this.tipos = new ArrayList<>(tipos);
    }

    public int getNumero() { return numero; }
    public String getNombre() { return nombre; }
    public double getPeso() { return peso; }
    public double getAltura() { return altura; }
    public List<String> getTipos() { return tipos; }

    @Override
    public String toString() {
        return numero + " - " + nombre + " (" + String.join(", ", tipos) + ") " + peso + " kg, " + altura + " m";
    }
}
