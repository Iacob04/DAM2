package plantillas;

import java.util.List;

import com.google.gson.annotations.SerializedName;

// CLASE RAÍZ DEL JSON: { "pokedex": [ {...}, {...} ] }
// Igual que la clase Agenda del profe. Solo hace falta si el JSON empieza por {
public class Pokedex {

    @SerializedName("pokedex")          // nombre de la clave en el JSON
    private List<Pokemon> pokemons;

    public Pokedex(List<Pokemon> pokemons) {
        this.pokemons = pokemons;
    }

    public List<Pokemon> getPokemons() {
        return pokemons;
    }
}
