package plantillas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

// Traducir el código de SQLException a un mensaje para el usuario
public class MensajesError {

    public static void main(String[] args) {
        insertarTipo(16, "Acero");        // ya existe (si hiciste el INSERT del enunciado) o se inserta
        insertarTipo(16, "Acero");        // la segunda vez seguro que choca
        insertarTipo(17, "Hadaaaaaaaaaaaa");
        guardarFecha();
    }

    public static void insertarTipo(int id, String nombre) {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pokemondb", "alumno", "abc123");
             PreparedStatement ps = con.prepareStatement("INSERT INTO tipo VALUES (?, ?, 1)")) {
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.executeUpdate();
            System.out.println("Tipo " + nombre + " insertado");
        } catch (SQLException e) {
            System.out.println(mensaje(e));
        }
    }

    public static String mensaje(SQLException e) {
        switch (e.getErrorCode()) {
            case 1045: return "Usuario o contraseña incorrectos";
            case 1049: return "La base de datos no existe";
            case 1146: return "La tabla no existe (¿mayúsculas?)";
            case 1054: return "Columna desconocida";
            case 1062: return "Ya existe un registro con esa clave";
            case 1451: return "No se puede borrar: otros datos dependen de este";
            case 1452: return "Referencia a un dato que no existe";
            case 1406: return "Texto demasiado largo para la columna";
            default:   return "Error " + e.getErrorCode() + ": " + e.getMessage();
        }
    }

    // Fecha y hora sin formatear a mano: setObject con LocalDateTime (JDBC 4.2)
    public static void guardarFecha() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", "alumno", "abc123");
             PreparedStatement ps = con.prepareStatement("INSERT INTO actor VALUES (NULL, ?, ?, ?)")) {
            ps.setString(1, "José María");
            ps.setString(2, "Morales");
            ps.setObject(3, LocalDateTime.now());          // sin DateTimeFormatter ni "YYYY"
            System.out.println("Filas insertadas: " + ps.executeUpdate());
        } catch (SQLException e) {
            System.out.println(mensaje(e));
        }
    }
}
