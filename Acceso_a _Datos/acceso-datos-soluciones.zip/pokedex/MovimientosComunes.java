package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.text.Collator;
import java.util.Map;
import java.util.TreeMap;

// R2. Movimientos que pueden aprender dos pokemon y cómo los aprende cada uno (nivel, MT o MO).
public class MovimientosComunes {

    public static void main(String[] args) {
        movimientosComunes("Pikachu", "Charmander");
        movimientosComunes("Magikarp", "Mewtwo");
        movimientosComunes("Pikachu", "Pikachu");
        movimientosComunes("Pikachu", "Agumon");
    }

    public static void movimientosComunes(String a, String b) {
        if (a.equalsIgnoreCase(b)) {
            System.out.println("Tienes que indicar dos pokemon distintos");
            return;
        }
        try (Connection con = Conexion.getConnection()) {
            int na = Conexion.numeroPokemon(con, a);
            int nb = Conexion.numeroPokemon(con, b);
            if (na == -1 || nb == -1) {
                System.out.println("El pokemon " + (na == -1 ? a : b) + " no está en la pokedex");
                return;
            }
            Map<String, List<String>> movA = movimientos(con, na);
            Map<String, List<String>> movB = movimientos(con, nb);

            List<String> comunes = new ArrayList<>();
            for (String mov : movA.keySet()) {          // TreeMap: ya salen en orden alfabético
                if (movB.containsKey(mov)) comunes.add(mov);
            }
            if (comunes.isEmpty()) {
                System.out.println(a + " y " + b + " no tienen ningún movimiento en común");
                return;
            }
            System.out.println("Movimientos que pueden aprender " + a + " y " + b + ": " + comunes.size());
            for (String mov : comunes) {
                System.out.println(" - " + mov + ": " + a + " (" + String.join(", ", movA.get(mov)) + ") | "
                        + b + " (" + String.join(", ", movB.get(mov)) + ")");
            }
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    // movimiento -> formas de aprenderlo. Un movimiento puede tener varias: Trueno (nivel 43, MT25)
    // MT, MO y nivel_aprendizaje son subtablas de forma_aprendizaje: LEFT JOIN a las tres + COALESCE
    static Map<String, List<String>> movimientos(Connection con, int numero) throws SQLException {
        String sql = "SELECT m.nombre, COALESCE(mt.MT, mo.MO, CONCAT('nivel ', na.nivel)) AS forma "
                   + "FROM pokemon_movimiento_forma pmf "
                   + "JOIN movimiento m ON pmf.id_movimiento = m.id_movimiento "
                   + "LEFT JOIN MT mt ON mt.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                   + "LEFT JOIN MO mo ON mo.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                   + "LEFT JOIN nivel_aprendizaje na ON na.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                   + "WHERE pmf.numero_pokedex = ? ORDER BY m.nombre, forma";
        // Collator: orden alfabético de verdad ("MegaPuño" tras "Megapatada", "Ácido" con la A).
        // Un TreeMap normal ordena por código Unicode: mayúsculas antes y tildes al final.
        Map<String, List<String>> mapa = new TreeMap<>(Collator.getInstance(Locale.forLanguageTag("es")));
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    mapa.computeIfAbsent(rs.getString("nombre"), k -> new ArrayList<>()).add(rs.getString("forma"));
                }
            }
        }
        return mapa;
    }
}
