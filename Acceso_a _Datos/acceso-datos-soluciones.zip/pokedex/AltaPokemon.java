package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

// R4. Dar de alta un pokemon completo: datos, tipos, estadísticas y, si evoluciona de otro, la evolución
// por nivel. Son hasta 7 tablas: o se guarda todo o nada (transacción).
public class AltaPokemon {

    public static void main(String[] args) {
        altaPokemon(152, "Chikorita", 6.4, 0.9, List.of("Planta"), new int[]{45, 49, 65, 49, 45}, null, 0);
        altaPokemon(153, "Bayleef", 15.8, 1.2, List.of("Planta"), new int[]{60, 62, 80, 63, 60}, "Chikorita", 16);
        altaPokemon(154, "Meganium", 100.5, 1.8, List.of("Planta", "Hada"), new int[]{80, 82, 100, 83, 80}, "Bayleef", 32);
        altaPokemon(25, "Pichu", 2.0, 0.3, List.of("Eléctrico"), new int[]{20, 40, 15, 35, 60}, null, 0);
        altaPokemon(155, "Cyndaquil", 7.9, 0.5, List.of("Fuego"), new int[]{39, 52, 43, 60, 65}, "Agumon", 14);
        LineaEvolutiva.lineaEvolutiva("Bayleef");             // comprobar con el ejercicio R1
    }

    public static void altaPokemon(int numero, String nombre, double peso, double altura, List<String> tipos,
                                   int[] stats, String evolucionaDe, int nivel) {
        if (tipos.isEmpty() || tipos.size() > 2 || stats.length != 5) {
            System.out.println("Un pokemon tiene 1 o 2 tipos y 5 estadísticas");
            return;
        }
        try (Connection con = Conexion.getConnection()) {
            con.setAutoCommit(false);
            try {
                if (Conexion.nombrePokemon(con, numero) != null)
                    throw new SQLException("ya existe el número " + numero + " (" + Conexion.nombrePokemon(con, numero) + ")");

                ejecutar(con, "INSERT INTO pokemon VALUES (?, ?, ?, ?)", numero, nombre, peso, altura);

                for (String tipo : tipos) {
                    int id = Conexion.idTipo(con, tipo);
                    if (id == -1) throw new SQLException("el tipo " + tipo + " no existe");
                    ejecutar(con, "INSERT INTO pokemon_tipo VALUES (?, ?)", numero, id);
                }

                ejecutar(con, "INSERT INTO estadisticas_base VALUES (?, ?, ?, ?, ?, ?)",
                        numero, stats[0], stats[1], stats[2], stats[3], stats[4]);

                if (evolucionaDe != null) {
                    int origen = Conexion.numeroPokemon(con, evolucionaDe);
                    if (origen == -1) throw new SQLException(evolucionaDe + " no está en la pokedex");
                    ejecutar(con, "INSERT INTO evoluciona_de VALUES (?, ?)", numero, origen);
                    // forma_evolucion NO es AUTO_INCREMENT: el id se calcula a mano
                    int idForma = siguienteIdForma(con);
                    ejecutar(con, "INSERT INTO forma_evolucion VALUES (?, 1)", idForma);       // 1 = Nivel
                    ejecutar(con, "INSERT INTO nivel_evolucion VALUES (?, ?)", idForma, nivel);
                    ejecutar(con, "INSERT INTO pokemon_forma_evolucion VALUES (?, ?)", origen, idForma); // cuelga del ORIGEN
                }
                con.commit();
                System.out.println("Alta de " + nombre + " (#" + numero + ") correcta");
            } catch (SQLException e) {
                con.rollback();                 // se deshacen también los INSERT que sí habían ido bien
                System.out.println("No se da de alta " + nombre + ": " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    // PreparedStatement genérico: los ? se rellenan en orden con setObject
    static int ejecutar(Connection con, String sql, Object... valores) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < valores.length; i++) ps.setObject(i + 1, valores[i]);
            return ps.executeUpdate();
        }
    }

    static int siguienteIdForma(Connection con) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT COALESCE(MAX(id_forma_evolucion), 0) + 1 FROM forma_evolucion");
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }
}
