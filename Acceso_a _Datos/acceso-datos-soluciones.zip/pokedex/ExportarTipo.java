package pokedex;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.GsonBuilder;

// R5. BD -> JSON anidado: todos los pokemon de un tipo con sus tipos, estadísticas y evoluciones.
public class ExportarTipo {

    // ---- Clases que dan forma al JSON (pueden ir en ficheros aparte) ----
    static class Estadisticas {
        int ps, ataque, defensa, especial, velocidad, total;
    }

    static class Ficha {
        int numero;
        String nombre;
        List<String> tipos = new ArrayList<>();
        Estadisticas estadisticas;                   // null si la BD no las tiene (Doduo)
        List<String> evolucionaEn = new ArrayList<>();
    }

    static class Exportacion {
        String tipo;
        int total;
        List<Ficha> pokemon = new ArrayList<>();
    }

    public static void main(String[] args) {
        exportarTipo("Dragón", "dragon.json");
        exportarTipo("Volador", "volador.json");
        exportarTipo("Acero", "acero.json");
    }

    public static void exportarTipo(String tipo, String fichero) {
        Exportacion exp = new Exportacion();
        exp.tipo = tipo;
        try (Connection con = Conexion.getConnection()) {
            int idTipo = Conexion.idTipo(con, tipo);
            if (idTipo == -1) {
                System.out.println(tipo + " no es un tipo de esta pokedex");
                return;
            }
            // LEFT JOIN a estadisticas_base: con JOIN normal Doduo desaparecería del fichero
            String sql = "SELECT p.numero_pokedex, p.nombre, eb.ps, eb.ataque, eb.defensa, eb.especial, eb.velocidad "
                       + "FROM pokemon p JOIN pokemon_tipo pt ON p.numero_pokedex = pt.numero_pokedex "
                       + "LEFT JOIN estadisticas_base eb ON eb.numero_pokedex = p.numero_pokedex "
                       + "WHERE pt.id_tipo = ? ORDER BY p.numero_pokedex";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idTipo);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Ficha f = new Ficha();
                        f.numero = rs.getInt("numero_pokedex");
                        f.nombre = rs.getString("nombre");
                        rs.getInt("ps");
                        if (!rs.wasNull()) {                  // ¿había fila en estadisticas_base?
                            Estadisticas e = new Estadisticas();
                            e.ps = rs.getInt("ps");
                            e.ataque = rs.getInt("ataque");
                            e.defensa = rs.getInt("defensa");
                            e.especial = rs.getInt("especial");
                            e.velocidad = rs.getInt("velocidad");
                            e.total = e.ps + e.ataque + e.defensa + e.especial + e.velocidad;
                            f.estadisticas = e;
                        }
                        exp.pokemon.add(f);
                    }
                }
            }
            // Segunda pasada: tipos y evoluciones de cada uno (otro ResultSet por pokemon)
            for (Ficha f : exp.pokemon) {
                f.tipos = textos(con, "SELECT t.nombre FROM pokemon_tipo pt JOIN tipo t ON pt.id_tipo = t.id_tipo "
                                    + "WHERE pt.numero_pokedex = ? ORDER BY t.id_tipo", f.numero);
                f.evolucionaEn = textos(con, "SELECT p.nombre FROM evoluciona_de e JOIN pokemon p "
                                    + "ON p.numero_pokedex = e.pokemon_evolucionado WHERE e.pokemon_origen = ? "
                                    + "ORDER BY p.numero_pokedex", f.numero);
            }
            exp.total = exp.pokemon.size();
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
            return;
        }

        if (exp.pokemon.isEmpty()) {
            System.out.println("No hay pokemon de tipo " + tipo + ": no se crea " + fichero);
            return;
        }
        try (Writer w = new FileWriter(fichero, StandardCharsets.UTF_8)) {
            // serializeNulls: sin esto, la clave "estadisticas" de Doduo no aparecería en el JSON
            new GsonBuilder().setPrettyPrinting().serializeNulls().create().toJson(exp, w);
            System.out.println("Exportados " + exp.total + " pokemon de tipo " + tipo + " a " + fichero);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fichero + ": " + e.getMessage());
        }
    }

    static List<String> textos(Connection con, String sql, int numero) throws SQLException {
        List<String> l = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) l.add(rs.getString(1));
            }
        }
        return l;
    }
}
