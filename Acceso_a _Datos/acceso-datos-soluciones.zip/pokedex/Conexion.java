package pokedex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// Conexión y búsquedas que usan todos los ejercicios de la pokedex.
// Si el profe pide pool, cambia getConnection por PoolConexiones.getConnection().
public class Conexion {

    static final String URL = "jdbc:mysql://localhost:3306/pokemondb";
    static final String USUARIO = "alumno";
    static final String PASSWORD = "abc123";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }

    // Número de pokedex a partir del nombre, o -1 si no existe
    public static int numeroPokemon(Connection con, String nombre) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT numero_pokedex FROM pokemon WHERE nombre = ?")) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }

    // Nombre a partir del número, o null si no existe
    public static String nombrePokemon(Connection con, int numero) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT nombre FROM pokemon WHERE numero_pokedex = ?")) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    // id del tipo a partir del nombre, o -1 si no existe
    public static int idTipo(Connection con, String tipo) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT id_tipo FROM tipo WHERE nombre = ?")) {
            ps.setString(1, tipo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }
}
