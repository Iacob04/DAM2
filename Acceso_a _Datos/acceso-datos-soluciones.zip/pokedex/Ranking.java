package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

// R3. Los N mejores pokemon de un tipo según la estadística que se pida. Los empates comparten puesto.
public class Ranking {

    static final List<String> ESTADISTICAS = List.of("ps", "ataque", "defensa", "especial", "velocidad", "total");

    public static void main(String[] args) {
        ranking("Fuego", "ataque", 5);
        ranking("Normal", "total", 3);
        ranking("Agua", "velocidad", 4);
        ranking("Fuego", "fuerza", 5);
        ranking("Luz", "ataque", 5);
    }

    public static void ranking(String tipo, String estadistica, int n) {
        estadistica = estadistica.toLowerCase();
        if (!ESTADISTICAS.contains(estadistica)) {      // OBLIGATORIO: la columna va pegada al SQL
            System.out.println(estadistica + " no es una estadística válida. Usa: " + String.join(", ", ESTADISTICAS));
            return;
        }
        if (n <= 0) {
            System.out.println("El número de pokemon tiene que ser mayor que 0");
            return;
        }
        // Un nombre de columna NO puede ir en un ?. Se concatena, pero solo tras validarlo arriba.
        String columna = estadistica.equals("total")
                ? "(eb.ps + eb.ataque + eb.defensa + eb.especial + eb.velocidad)"
                : "eb." + estadistica;
        String sql = "SELECT p.nombre, " + columna + " AS valor "
                   + "FROM pokemon p "
                   + "JOIN pokemon_tipo pt ON p.numero_pokedex = pt.numero_pokedex "
                   + "JOIN tipo t ON pt.id_tipo = t.id_tipo "
                   + "JOIN estadisticas_base eb ON eb.numero_pokedex = p.numero_pokedex "
                   + "WHERE t.nombre = ? ORDER BY valor DESC, p.numero_pokedex";
        try (Connection con = Conexion.getConnection()) {
            if (Conexion.idTipo(con, tipo) == -1) {
                System.out.println(tipo + " no es un tipo de esta pokedex");
                return;
            }
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, tipo);
                try (ResultSet rs = ps.executeQuery()) {
                    System.out.println("Top " + n + " de tipo " + tipo + " por " + estadistica + ":");
                    int fila = 0, puesto = 0, anterior = -1;
                    while (rs.next()) {
                        fila++;
                        int valor = rs.getInt("valor");
                        if (valor != anterior) puesto = fila;  // 1, 2, 2, 4: el empate repite puesto
                        if (puesto > n) break;                 // se para cuando el puesto (no la fila) pasa de n
                        System.out.println(puesto + ". " + rs.getString("nombre") + " - " + valor);
                        anterior = valor;
                    }
                    if (fila == 0) System.out.println("Ningún pokemon de tipo " + tipo + " tiene estadísticas");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }
}
