package pokedex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// R1. Línea evolutiva completa de un pokemon, desde la forma base, con cómo evoluciona cada uno.
public class LineaEvolutiva {

    public static void main(String[] args) {
        lineaEvolutiva("Ivysaur");
        lineaEvolutiva("Eevee");
        lineaEvolutiva("Charizard");
        lineaEvolutiva("Kadabra");
        lineaEvolutiva("Tauros");
        lineaEvolutiva("Venusaur");
    }

    public static void lineaEvolutiva(String nombre) {
        try (Connection con = Conexion.getConnection()) {
            int numero = Conexion.numeroPokemon(con, nombre);
            if (numero == -1) {
                System.out.println("El pokemon " + nombre + " no está en la pokedex");
                return;
            }
            // 1. Subir hasta la forma base. El Set evita dar vueltas si la BD tiene un ciclo.
            Set<Integer> vistos = new HashSet<>();
            int base = numero;
            vistos.add(base);
            List<Integer> padres = origenes(con, base);
            while (!padres.isEmpty() && !vistos.contains(padres.get(0))) {
                base = padres.get(0);
                vistos.add(base);
                padres = origenes(con, base);
            }

            if (base == numero && evoluciones(con, numero).isEmpty()) {
                System.out.println(nombre + " (#" + numero + ") no evoluciona ni viene de ningún otro pokemon");
                return;
            }
            // 2. Bajar desde la base, recursivamente
            System.out.println("Línea evolutiva de " + nombre + ":");
            System.out.println(Conexion.nombrePokemon(con, base) + " (#" + base + ")");
            bajar(con, base, 1, new HashSet<>(List.of(base)));
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    // Escribe las evoluciones de 'origen' con sangría y sigue con cada una de ellas
    static void bajar(Connection con, int origen, int nivel, Set<Integer> vistos) throws SQLException {
        String forma = formaEvolucion(con, origen);
        for (int hijo : evoluciones(con, origen)) {
            String sangria = "  ".repeat(nivel);
            String nombreHijo = Conexion.nombrePokemon(con, hijo);
            if (vistos.contains(hijo)) {           // sin esto: StackOverflowError con Charmeleon y Charizard
                System.out.println(sangria + "(dato circular en la BD: " + Conexion.nombrePokemon(con, origen)
                        + " -> " + nombreHijo + ", se ignora)");
                continue;
            }
            vistos.add(hijo);
            System.out.println(sangria + "-> " + nombreHijo + " (#" + hijo + ") " + forma);
            bajar(con, hijo, nivel + 1, vistos);
        }
    }

    // De quién viene (normalmente 0 o 1)
    static List<Integer> origenes(Connection con, int numero) throws SQLException {
        return lista(con, "SELECT pokemon_origen FROM evoluciona_de WHERE pokemon_evolucionado = ? ORDER BY 1", numero);
    }

    // En quién evoluciona (Eevee: 3)
    static List<Integer> evoluciones(Connection con, int numero) throws SQLException {
        return lista(con, "SELECT pokemon_evolucionado FROM evoluciona_de WHERE pokemon_origen = ? ORDER BY 1", numero);
    }

    static List<Integer> lista(Connection con, String sql, int numero) throws SQLException {
        List<Integer> l = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) l.add(rs.getInt(1));
            }
        }
        return l;
    }

    // Cómo evoluciona el pokemon 'origen'. La forma cuelga del ORIGEN, no del evolucionado.
    // nivel_evolucion y piedra son "subtablas": LEFT JOIN, porque cada forma solo está en una.
    static String formaEvolucion(Connection con, int origen) throws SQLException {
        String sql = "SELECT te.tipo_evolucion, ne.nivel, tp.nombre_piedra "
                   + "FROM pokemon_forma_evolucion pfe "
                   + "JOIN forma_evolucion fe ON pfe.id_forma_evolucion = fe.id_forma_evolucion "
                   + "JOIN tipo_evolucion te ON fe.tipo_evolucion = te.id_tipo_evolucion "
                   + "LEFT JOIN nivel_evolucion ne ON ne.id_forma_evolucion = fe.id_forma_evolucion "
                   + "LEFT JOIN piedra pi ON pi.id_forma_evolucion = fe.id_forma_evolucion "
                   + "LEFT JOIN tipo_piedra tp ON tp.id_tipo_piedra = pi.id_tipo_piedra "
                   + "WHERE pfe.numero_pokedex = ? ORDER BY tp.nombre_piedra";
        List<String> formas = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, origen);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    switch (rs.getString("tipo_evolucion")) {
                        case "Nivel" -> formas.add("al nivel " + rs.getInt("nivel"));
                        case "Piedra" -> formas.add("con " + rs.getString("nombre_piedra"));
                        default -> formas.add("por intercambio");
                    }
                }
            }
        }
        if (formas.isEmpty()) return "(la BD no dice cómo)";
        if (formas.size() == 1) return formas.get(0);
        // Eevee: 3 piedras y 3 evoluciones, pero la BD no relaciona cada piedra con su evolución
        return "(" + String.join(" / ", formas) + "; la BD no dice cuál)";
    }
}
