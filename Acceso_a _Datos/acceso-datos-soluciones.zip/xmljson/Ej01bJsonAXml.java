package xmljson;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.gson.Gson;

// El camino inverso: agenda.json de clase  ->  agenda.xml de clase (el DNI se pierde o va como atributo)
public class Ej01bJsonAXml {

    public static void main(String[] args) {
        jsonAXml("agenda.json", "agenda_desde_json.xml");
    }

    public static void jsonAXml(String fJson, String fXml) {
        Agenda agenda;
        try (Reader r = new FileReader(fJson, StandardCharsets.UTF_8)) {
            agenda = new Gson().fromJson(r, Agenda.class);
        } catch (Exception e) {
            System.out.println("Error al leer " + fJson + ": " + e.getMessage());
            return;
        }
        if (agenda == null || agenda.getContactos() == null) {
            System.out.println("El fichero " + fJson + " no tiene contactos");
            return;
        }

        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element raiz = doc.createElement("agenda");
            doc.appendChild(raiz);
            for (Contacto c : agenda.getContactos()) {
                Element contacto = doc.createElement("contacto");
                contacto.setAttribute("dni", c.getDni());          // así no se pierde el DNI
                Element nombre = doc.createElement("nombre");
                nombre.setTextContent(c.getNombre());
                Element telefono = doc.createElement("telefono");
                telefono.setTextContent(c.getTelefono());
                contacto.appendChild(nombre);
                contacto.appendChild(telefono);
                raiz.appendChild(contacto);
            }
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            t.transform(new DOMSource(doc), new StreamResult(new File(fXml)));
            System.out.println("Convertidos " + agenda.getContactos().size() + " contactos a " + fXml);
        } catch (Exception e) {
            System.out.println("Error al escribir " + fXml + ": " + e.getMessage());
        }
    }
}
