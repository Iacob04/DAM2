package xmljson;

import java.util.List;

import com.google.gson.annotations.SerializedName;

// Igual que la Agenda del profe: { "agenda": [ ... ] }
public class Agenda {
    @SerializedName("agenda")
    private List<Contacto> contactos;

    public List<Contacto> getContactos() { return contactos; }
    public void setContactos(List<Contacto> contactos) { this.contactos = contactos; }
}
