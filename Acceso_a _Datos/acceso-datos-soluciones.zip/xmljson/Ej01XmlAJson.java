package xmljson;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.GsonBuilder;

// agenda.xml de clase  ->  agenda.json con el formato de clase (DNI en blanco)
public class Ej01XmlAJson {

    public static void main(String[] args) {
        xmlAJson("agenda.xml", "agenda_convertida.json");
    }

    public static void xmlAJson(String fXml, String fJson) {
        List<Contacto> contactos = new ArrayList<>();
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(fXml));
            NodeList lista = doc.getElementsByTagName("contacto");
            for (int i = 0; i < lista.getLength(); i++) {
                Element contacto = (Element) lista.item(i);
                String nombre = contacto.getElementsByTagName("nombre").item(0).getTextContent().trim();
                String telefono = contacto.getElementsByTagName("telefono").item(0).getTextContent().trim();
                contactos.add(new Contacto(nombre, telefono, ""));     // el XML no tiene DNI
            }
        } catch (Exception e) {
            System.out.println("Error al leer " + fXml + ": " + e.getMessage());
            return;
        }

        Agenda agenda = new Agenda();
        agenda.setContactos(contactos);
        try (Writer w = new FileWriter(fJson, StandardCharsets.UTF_8)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(agenda, w);
            System.out.println("Convertidos " + contactos.size() + " contactos a " + fJson);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fJson + ": " + e.getMessage());
        }
    }
}
