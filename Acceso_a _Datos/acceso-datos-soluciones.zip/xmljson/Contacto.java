package xmljson;

// Igual que la Contacto del profe (agenda.json): un solo teléfono, como texto
public class Contacto {
    private String nombre;
    private String telefono;
    private String dni;

    public Contacto(String n, String t, String d) {
        this.nombre = n;
        this.telefono = t;
        this.dni = d;
    }

    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }
    public String getDni() { return dni; }
}
