package examen;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import com.google.gson.GsonBuilder;

// SOLUCIÓN del ejercicio 2
public class EjercicioFicheros {

    // ---------- clases que dan forma a los datos (y al JSON del apartado b) ----------
    static class Captura {
        String pokemon;
        int nivel;
        String fecha;
        Captura(String pokemon, int nivel, String fecha) { this.pokemon = pokemon; this.nivel = nivel; this.fecha = fecha; }
    }

    static class Entrenador {
        String id;
        String nombre;
        String ciudad;
        List<Captura> capturas = new ArrayList<>();
        Entrenador(String id, String nombre, String ciudad) { this.id = id; this.nombre = nombre; this.ciudad = ciudad; }

        double nivelMedio() {
            int suma = 0;
            for (Captura c : capturas) suma += c.nivel;
            return (double) suma / capturas.size();
        }

        Captura mejor() {
            Captura m = capturas.get(0);
            for (Captura c : capturas) if (c.nivel > m.nivel) m = c;
            return m;
        }
    }

    static class Exportacion {                       // raíz del JSON: { "entrenadores": [...] }
        List<Entrenador> entrenadores;
        Exportacion(List<Entrenador> e) { this.entrenadores = e; }
    }

    // Resultado de la lectura: los entrenadores y lo que no encajaba
    static int lineasIncorrectas;
    static Map<String, Integer> desconocidos;

    public static void main(String[] args) {
        String fEntrenadores = "entrenadores.txt";
        String fCapturas = "capturas.csv";
        informeCapturas(fEntrenadores, fCapturas);
        System.out.println();
        exportarJSON(fEntrenadores, fCapturas, "capturas.json");
        System.out.println();
        guardarRanking(fEntrenadores, fCapturas, "ranking.dat");
        mostrarRanking("ranking.dat");
        System.out.println();
        informeCapturas("noexiste.txt", fCapturas);
        mostrarRanking("noexiste.dat");
    }

    // ---------- lectura común a los tres apartados ----------
    // TreeMap por id no sirve para el orden alfabético: se ordena luego por nombre
    static Map<String, Entrenador> cargar(String fEntrenadores, String fCapturas) {
        Map<String, Entrenador> mapa = new LinkedHashMap<>();
        lineasIncorrectas = 0;
        desconocidos = new TreeMap<>();
        try {
            for (String linea : Files.readAllLines(Path.of(fEntrenadores), StandardCharsets.UTF_8)) {
                if (linea.isBlank()) continue;
                String[] c = linea.split(";");
                if (c.length == 3) mapa.put(c[0].trim(), new Entrenador(c[0].trim(), c[1].trim(), c[2].trim()));
            }
            List<String> lineas = Files.readAllLines(Path.of(fCapturas), StandardCharsets.UTF_8);
            for (int i = 1; i < lineas.size(); i++) {                    // la 0 es la cabecera
                String linea = lineas.get(i);
                if (linea.isBlank()) continue;
                String[] c = linea.split(",", -1);
                try {
                    if (c.length != 4 || c[1].isBlank() || c[3].isBlank()) throw new NumberFormatException();
                    int nivel = Integer.parseInt(c[2].trim());
                    if (nivel < 1 || nivel > 100) throw new NumberFormatException();
                    Entrenador e = mapa.get(c[0].trim());
                    if (e == null) {
                        desconocidos.merge(c[0].trim(), 1, Integer::sum);
                    } else {
                        e.capturas.add(new Captura(c[1].trim(), nivel, c[3].trim()));
                    }
                } catch (NumberFormatException e) {
                    lineasIncorrectas++;
                }
            }
            return mapa;
        } catch (java.nio.file.NoSuchFileException e) {
            System.out.println("No existe el fichero " + e.getMessage());
            return null;
        } catch (IOException e) {
            System.out.println("Error al leer los ficheros: " + e.getMessage());
            return null;
        }
    }

    static List<Entrenador> ordenadosPorNombre(Map<String, Entrenador> mapa) {
        List<Entrenador> l = new ArrayList<>(mapa.values());
        l.sort((a, b) -> a.nombre.compareTo(b.nombre));
        return l;
    }

    static String dos(double x) {
        return String.format(Locale.US, "%.2f", x);
    }

    // ---------- a) ----------
    public static void informeCapturas(String fEntrenadores, String fCapturas) {
        Map<String, Entrenador> mapa = cargar(fEntrenadores, fCapturas);
        if (mapa == null) return;
        System.out.println("INFORME DE CAPTURAS");
        for (Entrenador e : ordenadosPorNombre(mapa)) {
            if (e.capturas.isEmpty()) {
                System.out.println(e.nombre + " (" + e.ciudad + "): sin capturas");
            } else {
                Captura m = e.mejor();
                System.out.println(e.nombre + " (" + e.ciudad + "): " + e.capturas.size() + " capturas, nivel medio "
                        + dos(e.nivelMedio()) + ", mejor captura " + m.pokemon + " (nivel " + m.nivel + ")");
            }
        }
        System.out.println("Líneas incorrectas: " + lineasIncorrectas);
        if (!desconocidos.isEmpty()) {
            List<String> l = new ArrayList<>();
            for (Map.Entry<String, Integer> d : desconocidos.entrySet()) l.add(d.getKey() + " (" + d.getValue() + ")");
            System.out.println("Capturas de entrenadores desconocidos: " + String.join(", ", l));
        }
    }

    // ---------- b) ----------
    public static void exportarJSON(String fEntrenadores, String fCapturas, String fJson) {
        Map<String, Entrenador> mapa = cargar(fEntrenadores, fCapturas);
        if (mapa == null) return;
        try (Writer w = new FileWriter(fJson, StandardCharsets.UTF_8)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(new Exportacion(new ArrayList<>(mapa.values())), w);
            System.out.println("Exportados " + mapa.size() + " entrenadores a " + fJson);
        } catch (IOException e) {
            System.out.println("Error al escribir " + fJson + ": " + e.getMessage());
        }
    }

    // ---------- c) ----------
    public static void guardarRanking(String fEntrenadores, String fCapturas, String fDat) {
        Map<String, Entrenador> mapa = cargar(fEntrenadores, fCapturas);
        if (mapa == null) return;
        List<Entrenador> l = new ArrayList<>();
        for (Entrenador e : mapa.values()) if (!e.capturas.isEmpty()) l.add(e);
        l.sort((a, b) -> a.capturas.size() != b.capturas.size()
                ? b.capturas.size() - a.capturas.size()        // más capturas primero
                : a.nombre.compareTo(b.nombre));               // empate: alfabético
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(fDat))) {
            for (Entrenador e : l) {
                dos.writeUTF(e.nombre);
                dos.writeInt(e.capturas.size());
                dos.writeDouble(e.nivelMedio());
            }
            System.out.println("Ranking guardado en " + fDat + " (" + l.size() + " entrenadores)");
        } catch (IOException e) {
            System.out.println("Error al escribir " + fDat + ": " + e.getMessage());
        }
    }

    public static void mostrarRanking(String fDat) {
        try (DataInputStream dis = new DataInputStream(new FileInputStream(fDat))) {
            int puesto = 1;
            while (true) {
                String nombre = dis.readUTF();
                int capturas = dis.readInt();
                double media = dis.readDouble();
                System.out.println(puesto + ". " + nombre + " - " + capturas + " capturas - nivel medio " + dos(media));
                puesto++;
            }
        } catch (EOFException e) {
            // fin del fichero
        } catch (FileNotFoundException e) {
            System.out.println("No existe el fichero " + fDat);
        } catch (IOException e) {
            System.out.println("Error al leer " + fDat + ": " + e.getMessage());
        }
    }
}
