package examen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// SOLUCIÓN del ejercicio 1
public class EjercicioBBDD {

    static final String URL = "jdbc:mysql://localhost:3306/pokemondb";
    static final String USUARIO = "alumno";
    static final String PASSWORD = "abc123";

    public static void main(String[] args) {
        fichaPokemon("Charmander");
        fichaPokemon("Doduo");
        fichaPokemon("Venusaur");
        System.out.println();
        quienAprende("Lanzallamas");
        quienAprende("Comesueños");
        quienAprende("Danza lluvia");
        System.out.println();
        aprenderMovimiento("Charmander", "Lanzallamas", 30);
        aprenderMovimiento("Charmander", "Terremoto", 30);
        aprenderMovimiento("Charmander", "Surf", 57);
        aprenderMovimiento("Agumon", "Surf", 20);
        aprenderMovimiento("Charmander", "Danza lluvia", 20);
        aprenderMovimiento("Charmander", "Surf", 120);
        fichaPokemon("Charmander");
    }

    static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }

    // id a partir de un nombre, o -1 si no existe
    static int buscarId(Connection con, String sql, String nombre) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }

    static int idPokemon(Connection con, String nombre) throws SQLException {
        return buscarId(con, "SELECT numero_pokedex FROM pokemon WHERE nombre = ?", nombre);
    }

    static int idMovimiento(Connection con, String nombre) throws SQLException {
        return buscarId(con, "SELECT id_movimiento FROM movimiento WHERE nombre = ?", nombre);
    }

    // 8.5 -> "8.5"   210.0 -> "210"
    static String num(double d) {
        return d == Math.floor(d) ? String.valueOf((long) d) : String.valueOf(d);
    }

    // ---------- a) ----------
    public static void fichaPokemon(String nombre) {
        try (Connection con = conectar()) {
            int numero = idPokemon(con, nombre);
            if (numero == -1) {
                System.out.println("El pokemon " + nombre + " no está en la pokedex");
                return;
            }
            String sql = "SELECT p.nombre, p.peso, p.altura, eb.ps, eb.ataque, eb.defensa, eb.especial, eb.velocidad "
                       + "FROM pokemon p LEFT JOIN estadisticas_base eb ON eb.numero_pokedex = p.numero_pokedex "
                       + "WHERE p.numero_pokedex = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, numero);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    System.out.println("#" + numero + " " + rs.getString("nombre"));
                    System.out.println("Tipos: " + String.join(", ", tipos(con, numero)));
                    System.out.println("Peso: " + num(rs.getDouble("peso")) + " kg. Altura: " + num(rs.getDouble("altura")) + " m");
                    int ps1 = rs.getInt("ps");
                    if (rs.wasNull()) {
                        System.out.println("Estadísticas: no registradas");
                    } else {
                        int at = rs.getInt("ataque"), de = rs.getInt("defensa"), es = rs.getInt("especial"), ve = rs.getInt("velocidad");
                        System.out.println("Estadísticas: PS " + ps1 + " | Ataque " + at + " | Defensa " + de + " | Especial " + es
                                + " | Velocidad " + ve + " | Total " + (ps1 + at + de + es + ve));
                    }
                }
            }
            // Movimientos por nivel agrupados: nivel -> movimientos
            String sqlMov = "SELECT na.nivel, m.nombre FROM pokemon_movimiento_forma pmf "
                          + "JOIN nivel_aprendizaje na ON na.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                          + "JOIN movimiento m ON m.id_movimiento = pmf.id_movimiento "
                          + "WHERE pmf.numero_pokedex = ? ORDER BY na.nivel, m.nombre";
            Map<Integer, List<String>> porNivel = new LinkedHashMap<>();
            try (PreparedStatement ps = con.prepareStatement(sqlMov)) {
                ps.setInt(1, numero);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) porNivel.computeIfAbsent(rs.getInt(1), k -> new ArrayList<>()).add(rs.getString(2));
                }
            }
            if (porNivel.isEmpty()) {
                System.out.println("No aprende movimientos por nivel");
            } else {
                System.out.println("Movimientos por nivel:");
                for (Map.Entry<Integer, List<String>> e : porNivel.entrySet())
                    System.out.println(" Nivel " + e.getKey() + ": " + String.join(", ", e.getValue()));
            }
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    static List<String> tipos(Connection con, int numero) throws SQLException {
        List<String> l = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT t.nombre FROM pokemon_tipo pt JOIN tipo t ON pt.id_tipo = t.id_tipo WHERE pt.numero_pokedex = ? ORDER BY t.id_tipo")) {
            ps.setInt(1, numero);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) l.add(rs.getString(1));
            }
        }
        return l;
    }

    // ---------- b) ----------
    public static void quienAprende(String movimiento) {
        try (Connection con = conectar()) {
            String datos = "SELECT m.id_movimiento, t.nombre, m.potencia FROM movimiento m JOIN tipo t ON m.id_tipo = t.id_tipo WHERE m.nombre = ?";
            int id;
            String tipo;
            int potencia;
            try (PreparedStatement ps = con.prepareStatement(datos)) {
                ps.setString(1, movimiento);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        System.out.println("El movimiento " + movimiento + " no existe");
                        return;
                    }
                    id = rs.getInt(1);
                    tipo = rs.getString(2);
                    potencia = rs.getInt(3);
                }
            }
            // Un pokemon puede aprenderlo de varias formas: se agrupan por pokemon
            String sql = "SELECT p.nombre, COALESCE(mt.MT, mo.MO, CONCAT('nivel ', na.nivel)) AS forma "
                       + "FROM pokemon_movimiento_forma pmf JOIN pokemon p ON p.numero_pokedex = pmf.numero_pokedex "
                       + "LEFT JOIN MT mt ON mt.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                       + "LEFT JOIN MO mo ON mo.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                       + "LEFT JOIN nivel_aprendizaje na ON na.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                       + "WHERE pmf.id_movimiento = ? ORDER BY p.numero_pokedex, forma";
            Map<String, List<String>> quien = new LinkedHashMap<>();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) quien.computeIfAbsent(rs.getString(1), k -> new ArrayList<>()).add(rs.getString(2));
                }
            }
            if (quien.isEmpty()) {
                System.out.println("Ningún pokemon aprende " + movimiento);
                return;
            }
            System.out.println(movimiento + " (tipo " + tipo + ", potencia " + potencia + ") lo aprenden " + quien.size() + " pokemon:");
            for (Map.Entry<String, List<String>> e : quien.entrySet())
                System.out.println(" - " + e.getKey() + " (" + String.join(", ", e.getValue()) + ")");
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }

    // ---------- c) ----------
    public static void aprenderMovimiento(String pokemon, String movimiento, int nivel) {
        if (nivel < 1 || nivel > 100) {
            System.out.println("El nivel tiene que estar entre 1 y 100");
            return;
        }
        try (Connection con = conectar()) {
            int numero = idPokemon(con, pokemon);
            if (numero == -1) {
                System.out.println("El pokemon " + pokemon + " no está en la pokedex");
                return;
            }
            int idMov = idMovimiento(con, movimiento);
            if (idMov == -1) {
                System.out.println("El movimiento " + movimiento + " no existe");
                return;
            }
            // ¿Ya lo aprende de alguna forma? (nivel, MT o MO)
            String sqlYa = "SELECT COALESCE(mt.MT, mo.MO, CONCAT('nivel ', na.nivel)) FROM pokemon_movimiento_forma pmf "
                         + "LEFT JOIN MT mt ON mt.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                         + "LEFT JOIN MO mo ON mo.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                         + "LEFT JOIN nivel_aprendizaje na ON na.id_forma_aprendizaje = pmf.id_forma_aprendizaje "
                         + "WHERE pmf.numero_pokedex = ? AND pmf.id_movimiento = ?";
            try (PreparedStatement ps = con.prepareStatement(sqlYa)) {
                ps.setInt(1, numero);
                ps.setInt(2, idMov);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        System.out.println(pokemon + " ya aprende " + movimiento + " (" + rs.getString(1) + ")");
                        return;
                    }
                }
            }
            con.setAutoCommit(false);
            try {
                // ¿Ya hay una forma de aprendizaje para ese nivel? (hay una por nivel, compartida)
                int idForma = -1;
                try (PreparedStatement ps = con.prepareStatement("SELECT id_forma_aprendizaje FROM nivel_aprendizaje WHERE nivel = ?")) {
                    ps.setInt(1, nivel);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) idForma = rs.getInt(1);
                    }
                }
                if (idForma == -1) {                               // no la hay: se crea (AUTO_INCREMENT)
                    try (PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO forma_aprendizaje (id_tipo_aprendizaje) VALUES (3)", Statement.RETURN_GENERATED_KEYS)) {
                        ps.executeUpdate();
                        try (ResultSet rs = ps.getGeneratedKeys()) {
                            rs.next();
                            idForma = rs.getInt(1);                // el id que acaba de generar la BD
                        }
                    }
                    try (PreparedStatement ps = con.prepareStatement("INSERT INTO nivel_aprendizaje VALUES (?, ?)")) {
                        ps.setInt(1, idForma);
                        ps.setInt(2, nivel);
                        ps.executeUpdate();
                    }
                    System.out.println("Creada la forma de aprendizaje para el nivel " + nivel);
                }
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO pokemon_movimiento_forma VALUES (?, ?, ?)")) {
                    ps.setInt(1, numero);
                    ps.setInt(2, idMov);
                    ps.setInt(3, idForma);
                    ps.executeUpdate();
                }
                con.commit();
                System.out.println(pokemon + " aprende ahora " + movimiento + " al nivel " + nivel);
            } catch (SQLException e) {
                con.rollback();
                System.out.println("No se ha guardado nada: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
        }
    }
}
